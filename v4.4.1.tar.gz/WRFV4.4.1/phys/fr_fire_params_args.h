,xifms,xifme,xjfms,xjfme &
,vx,vy,zsf,bbb,betafl,phiwc,r_0,fgip,ischap &
